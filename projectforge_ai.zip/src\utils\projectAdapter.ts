import type { Project } from '../data/projectsDatabase';

export interface SystemNode {
  id: string;
  label: string;
  type: 'hardware' | 'software' | 'cloud' | 'database' | 'user';
  description: string;
}

export interface SystemConnection {
  from: string;
  to: string;
  protocol: string;
}

export interface AdaptedProject extends Project {
  // Adapted details
  primaryLanguage: string;
  systemArchitecture: {
    nodes: SystemNode[];
    connections: SystemConnection[];
  };
  databaseDesign: {
    engine: string;
    tables: {
      name: string;
      columns: { name: string; type: string; constraints?: string }[];
    }[];
  };
  folderStructure: string;
  developmentRoadmap: {
    step: number;
    title: string;
    description: string;
    resources: string[];
    isCompleted: boolean;
  }[];
  sourceCodeStructureExplanation: { file: string; explanation: string }[];
  apisRequired: { route: string; method: string; description: string }[];
  testingProcedures: { type: string; command: string; details: string }[];
  commonErrors: { error: string; context: string; fix: string }[];
  vivaQuestions: { question: string; answer: string }[];
  resumeDescription: string[];
  githubReadmeTemplate: string;
}

export function adaptProject(project: Project, profile: {
  branch: string;
  specialization: string;
  languages: string[];
  skillLevel: string;
  academicYear: string;
}): AdaptedProject {
  // Determine primary language based on overlap and project capabilities
  let primaryLanguage = project.languages[0];
  const matchedLang = profile.languages.find(l => project.languages.includes(l));
  if (matchedLang) primaryLanguage = matchedLang;

  const isAdvanced = profile.skillLevel === 'Advanced' || profile.academicYear === '4th Year';

  // 1. Generate System Architecture Graph
  const nodes: SystemNode[] = [
    { id: 'usr', label: 'Client / User App', type: 'user', description: 'Web/Mobile front-end representing input triggers and data visualization graphs.' }
  ];
  const connections: SystemConnection[] = [];

  // Add hardware nodes if project has hardware
  if (project.hardware.length > 0) {
    nodes.push({ id: 'mcu', label: project.hardware[0], type: 'hardware', description: 'Core micro-controller processing sensor signals and executing logic loops.' });
    nodes.push({ id: 'sens', label: 'Sensor Array', type: 'hardware', description: 'Transducer elements recording physical properties (voltages, temperatures, motion).' });
    nodes.push({ id: 'act', label: 'Actuators / Relays', type: 'hardware', description: 'Relays, valves, or motor drives reacting to controller logic commands.' });

    connections.push({ from: 'sens', to: 'mcu', protocol: 'I2C / Analog' });
    connections.push({ from: 'mcu', to: 'act', protocol: 'GPIO / PWM Signal' });
    connections.push({ from: 'mcu', to: 'srv', protocol: 'MQTT / HTTP' });
  } else {
    connections.push({ from: 'usr', to: 'srv', protocol: 'HTTPS REST / WebSocket' });
  }

  // Server & Database Nodes
  nodes.push({ id: 'srv', label: 'App server Gateway', type: 'software', description: `Backend processor running on ${primaryLanguage} executing logic and database queries.` });
  const dbEngine = (primaryLanguage === 'Python' || primaryLanguage === 'SQL') ? 'PostgreSQL' : (primaryLanguage === 'JavaScript' || primaryLanguage === 'TypeScript') ? 'MongoDB' : 'SQLite';
  nodes.push({ id: 'db', label: `${dbEngine} Instance`, type: 'database', description: 'Persistent local storage recording telemetry logs, profile setups, and transaction audits.' });
  connections.push({ from: 'srv', to: 'db', protocol: 'TCP/IP connection' });

  if (isAdvanced) {
    nodes.push({ id: 'cld', label: 'Docker Container / Cloud host', type: 'cloud', description: 'Isolated host deploying microservice modules for automated monitoring.' });
    connections.push({ from: 'srv', to: 'cld', protocol: 'Docker Socket' });
  }

  // 2. Database Design Schema
  const tables = [
    {
      name: 'projects_telemetry',
      columns: [
        { name: 'id', type: 'UUID', constraints: 'PRIMARY KEY' },
        { name: 'timestamp', type: 'TIMESTAMP', constraints: 'DEFAULT NOW()' },
        { name: 'metric_name', type: 'VARCHAR(100)', constraints: 'NOT NULL' },
        { name: 'metric_value', type: 'NUMERIC(10,4)', constraints: 'NOT NULL' }
      ]
    },
    {
      name: 'system_configurations',
      columns: [
        { name: 'config_key', type: 'VARCHAR(50)', constraints: 'PRIMARY KEY' },
        { name: 'config_value', type: 'TEXT', constraints: 'NOT NULL' },
        { name: 'updated_at', type: 'TIMESTAMP', constraints: '' }
      ]
    }
  ];

  if (isAdvanced) {
    tables.push({
      name: 'audit_logs',
      columns: [
        { name: 'log_id', type: 'SERIAL', constraints: 'PRIMARY KEY' },
        { name: 'severity', type: 'VARCHAR(10)', constraints: 'NOT NULL' },
        { name: 'message', type: 'TEXT', constraints: 'NOT NULL' }
      ]
    });
  }

  // 3. Dynamic Folder Structure by Language
  let folderStructure = '';
  const fileExps: { file: string; explanation: string }[] = [];
  const apis: { route: string; method: string; description: string }[] = [];
  const testCmds: { type: string; command: string; details: string }[] = [];

  const lowerLang = primaryLanguage.toLowerCase();

  if (lowerLang === 'python') {
    folderStructure = `my-project/
├── requirements.txt         # Package dependencies (FastAPI, PyYAML, psycopg2)
├── README.md                # General system documentation and setup guides
├── config.yaml              # App variables, connection strings, and threshold configurations
├── src/
│   ├── __init__.py          # Marks folder as python package
│   ├── main.py              # Application runner initializing server APIs
│   ├── controller.py        # Logic execution routines and algorithm balancing
│   ├── database.py          # Session engines, DB clients, and SQL model managers
│   └── utils.py             # Helper tools for calculation models
└── tests/
    └── test_controller.py   # Unit testing suite executing Pytest assertions`;

    fileExps.push(
      { file: 'src/main.py', explanation: 'Initializes the FastAPI framework and mounts endpoint routes.' },
      { file: 'src/controller.py', explanation: `Implements the core logic calculations using customized ${primaryLanguage} libraries.` },
      { file: 'src/database.py', explanation: 'Creates connection pools and handles transactions.' }
    );

    apis.push(
      { route: '/api/v1/telemetry', method: 'POST', description: 'Submits new sensor readings or operation logs.' },
      { route: '/api/v1/telemetry/stats', method: 'GET', description: 'Returns rolling average summaries and alert statuses.' }
    );

    testCmds.push(
      { type: 'Unit Testing', command: 'pytest tests/', details: 'Runs validation checks on the logic algorithms.' },
      { type: 'Lint Check', command: 'flake8 src/', details: 'Enforces code style styling and identifies imports errors.' }
    );
  } else if (lowerLang === 'javascript' || lowerLang === 'typescript') {
    const ext = lowerLang === 'typescript' ? 'ts' : 'js';
    folderStructure = `my-project/
├── package.json             # NPM package scripts and module dependencies
├── tsconfig.json            # (TS only) Compiler directives and path configurations
├── src/
│   ├── index.${ext}            # App entry gate binding port listeners
│   ├── server.${ext}           # Express app setup and middleware routing
│   ├── service.${ext}          # Core logic algorithms and calculations
│   ├── model.${ext}            # Mongoose schemas for collections data structure
│   └── db.${ext}               # Client connection helper class
└── tests/
    └── index.test.${ext}       # Testing suite running Jest / Supertest specs`;

    fileExps.push(
      { file: `src/index.${ext}`, explanation: 'Launches the Express framework server on target ports.' },
      { file: `src/service.${ext}`, explanation: 'Executes core mathematics, signal models, or decision arrays.' }
    );

    apis.push(
      { route: '/api/telemetry', method: 'POST', description: 'Appends data frames to storage schemas.' },
      { route: '/api/health', method: 'GET', description: 'Verifies DB socket connection and sensor status.' }
    );

    testCmds.push(
      { type: 'Unit Testing', command: 'npm test', details: 'Executes Jest unit test scripts.' },
      { type: 'Type Verification', command: 'npx tsc --noEmit', details: 'Verifies compilation constraints across types.' }
    );
  } else if (lowerLang === 'c++' || lowerLang === 'c') {
    folderStructure = `my-project/
├── CMakeLists.txt           # Build compiler configurations mapping binaries
├── main.cpp                 # Main program containing MCU setup() and loop() hooks
├── Config.h                 # Preprocessor variables, pin layouts, and wifi keys
├── sensor_handler.cpp       # Handlers measuring I2C and analog data arrays
├── sensor_handler.h        # Interface headers for handlers
├── actuator_controller.cpp  # Output controller mapping relays, solenoids, or motors
└── tests/
    └── test_main.cpp        # GTest code simulating mock sensor inputs`;

    fileExps.push(
      { file: 'main.cpp', explanation: 'Establishes device setups and fires continuous sensor polling loops.' },
      { file: 'sensor_handler.cpp', explanation: 'Addresses hardware addresses to collect values.' }
    );

    apis.push(
      { route: 'MQTT /telemetry', method: 'PUB', description: 'Publishes payload string to active brokers.' },
      { route: 'MQTT /configs', method: 'SUB', description: 'Subscribes to updates containing threshold variables.' }
    );

    testCmds.push(
      { type: 'Build Check', command: 'cmake -B build/ && cmake --build build/', details: 'Compiles binaries and resolves platform libraries.' },
      { type: 'Flash Firmware', command: 'pio run --target upload', details: 'Flashes target executable compiled files to hardware pins.' }
    );
  } else {
    // Fallback template
    folderStructure = `my-project/
├── config.json              # Connection and variable tags
├── main.${primaryLanguage.toLowerCase()} # Core application entry
├── logic.${primaryLanguage.toLowerCase()} # Logic handler functions
└── tests/
    └── test_logic.py        # Verification files`;

    fileExps.push({ file: `main.${primaryLanguage.toLowerCase()}`, explanation: 'Launches the program runtime.' });
    apis.push({ route: '/api/telemetry', method: 'POST', description: 'Accepts telemetry frames.' });
    testCmds.push({ type: 'Verification', command: 'npm run test / pytest', details: 'Performs assertion audits.' });
  }

  // 4. Custom Development Roadmap
  const developmentRoadmap = [
    {
      step: 1,
      title: "Environment Initialization",
      description: `Install software tools: ${project.software.join(', ')}. Scaffolds project directories matching the file tree layouts.`,
      resources: ["VS Code installation guide", "Vite/PlatformIO documentation"],
      isCompleted: false
    },
    {
      step: 2,
      title: "Database and Telemetry Schema Configuration",
      description: `Configure ${dbEngine} database connection. Setup schemas, tables, and keys constraints.`,
      resources: ["Database normalization guidelines", "SQL/NoSQL cheat sheets"],
      isCompleted: false
    },
    {
      step: 3,
      title: "Core Logic Algorithm Implementation",
      description: `Build key processing models in ${primaryLanguage} representing the system objective: "${project.objective}".`,
      resources: [`Introduction to ${primaryLanguage} programming`, "Domain algorithm basics"],
      isCompleted: false
    }
  ];

  if (project.hardware.length > 0) {
    developmentRoadmap.push({
      step: 4,
      title: "Hardware Wiring and Firmware Assembly",
      description: `Assemble hardware elements: ${project.hardware.join(', ')}. Connect analog sensor nodes to MCU GPIO pins.`,
      resources: ["Breadboard wiring diagrams", "Sensor datasheets"],
      isCompleted: false
    });
  }

  developmentRoadmap.push(
    {
      step: developmentRoadmap.length + 1,
      title: "API Endpoint Routing & Web View",
      description: "Implement API endpoints and mount HTML dashboards to render tables and telemetry graphs.",
      resources: ["REST API design guidelines", "Chart.js/SVG integration models"],
      isCompleted: false
    },
    {
      step: developmentRoadmap.length + 1,
      title: "Verification & Testing procedures",
      description: `Write and run automated tests using commands: "${testCmds[0]?.command || 'npm test'}". Verify validations.`,
      resources: ["Unit testing best practices", "Mocking libraries setups"],
      isCompleted: false
    }
  );

  if (isAdvanced) {
    developmentRoadmap.push({
      step: developmentRoadmap.length + 1,
      title: "Containerization and Cloud Deployment Setup",
      description: "Draft a Dockerfile and docker-compose.yml configuration to bind containers, and prepare CI/CD pipeline variables.",
      resources: ["Docker Hub guides", "GitHub Actions workflows"],
      isCompleted: false
    });
  }

  // 5. Common Errors and Fixes
  const commonErrors = [
    {
      error: "Connection Refused / Network Timeout",
      context: "Occurs during initial API or database handshakes.",
      fix: "Verify local database service is active. Check firewall rules allowing port traffic."
    },
    {
      error: "Null Pointer Reference / Unresolved Imports",
      context: "Occurs during compiler executions.",
      fix: `Ensure all library files are listed inside dependencies documents (requirements.txt, package.json). Run rebuild checks.`
    }
  ];

  if (project.hardware.length > 0) {
    commonErrors.push({
      error: "Sensor returning NaN / Float Overflow",
      context: "Occurs during reading operations on hardware pins.",
      fix: "Check physical jumper wiring. Verify pull-up resistors are correctly bridged to VCC."
    });
  }

  // 6. Viva Preparation Questions
  const vivaQuestions = [
    {
      question: "What is the primary problem statement addressed by this engineering project?",
      answer: project.problemStatement
    },
    {
      question: `Why was ${primaryLanguage} selected as the development language instead of other options?`,
      answer: `Because of its native support for the project requirements: ${project.languages.join(', ')} provide optimal libraries, fast execution times, and compatibility with the target hardware/software environment.`
    },
    {
      question: "Explain the database architecture and normalization strategy used.",
      answer: `The system uses ${dbEngine} to record transactions and logs. The schema features normalized relational fields or decoupled JSON schemas depending on read/write loads to minimize duplicates.`
    },
    {
      question: "How would you handle scale constraints if database transactions multiply by a factor of 100?",
      answer: "Implement connection pooling, index lookup columns, add a caching layer (like Redis), and segregate high-rate logs write tables from analytics configurations."
    }
  ];

  // 7. Resume bullet descriptions
  const resumeDescription = [
    `Engineered an automated "${project.name}" system utilizing ${primaryLanguage} to target real-world challenges: "${project.problemStatement.slice(0, 100)}..."`,
    `Developed optimized backend controller modules on ${dbEngine} database models, improving calculation thresholds.`,
    `Assembled test validation pipelines resolving system latency and logic errors across multiple staging tests.`
  ];

  if (project.hardware.length > 0) {
    resumeDescription.push(`Designed low-power hardware configurations wiring sensors with ESP32/Arduino microcontrollers, minimizing power draws.`);
  }

  // 8. GitHub README Template
  const githubReadmeTemplate = `# ${project.name}

## Overview
${project.objective}

This project targets the following problem:
> ${project.problemStatement}

## Technologies Used
- **Language**: ${primaryLanguage}
- **Software**: ${project.software.join(', ')}
${project.hardware.length > 0 ? `- **Hardware**: ${project.hardware.join(', ')}` : ''}

## Directory Structure
\`\`\`
${folderStructure}
\`\`\`

## Quick Start
1. Clone the repository.
2. Initialize configurations.
3. Install dependencies:
   \`\`\`bash
   # Execute dependency setups
   ${lowerLang === 'python' ? 'pip install -r requirements.txt' : lowerLang.includes('js') ? 'npm install' : 'cmake -B build'}
   \`\`\`
4. Run the application:
   \`\`\`bash
   ${lowerLang === 'python' ? 'python src/main.py' : lowerLang.includes('js') ? 'npm start' : './build/main'}
   \`\`\`

## Verification
Run tests to check local configurations:
\`\`\`bash
${testCmds[0]?.command || 'npm test'}
\`\`\`

## License
MIT License
`;

  return {
    ...project,
    primaryLanguage,
    systemArchitecture: { nodes, connections },
    databaseDesign: { engine: dbEngine, tables },
    folderStructure,
    developmentRoadmap,
    sourceCodeStructureExplanation: fileExps,
    apisRequired: apis,
    testingProcedures: testCmds,
    commonErrors,
    vivaQuestions,
    resumeDescription,
    githubReadmeTemplate
  };
}
