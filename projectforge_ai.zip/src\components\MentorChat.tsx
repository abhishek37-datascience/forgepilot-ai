import { useState, useEffect, useRef } from 'react';
import { Send, Sparkles, MessageSquare, Terminal, HelpCircle, X, ChevronUp, ChevronDown } from 'lucide-react';
import type { AdaptedProject } from '../utils/projectAdapter';
import { api } from '../utils/api';

interface MentorChatProps {
  project: AdaptedProject;
  theme: 'dark' | 'light';
  progressPercent: number;
  completedSteps: number[];
  onClose?: () => void;
}

interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
}

export default function MentorChat({
  project,
  theme,
  progressPercent,
  completedSteps,
  onClose
}: MentorChatProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [inputMsg, setInputMsg] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Identify first incomplete step
  const activeStep = project.developmentRoadmap.find(s => !completedSteps.includes(s.step)) 
    || project.developmentRoadmap[project.developmentRoadmap.length - 1];

  // Initialize welcome message matching the active step
  useEffect(() => {
    setMessages([
      {
        sender: 'ai',
        text: `Hi! I'm your AI Mentor for **${project.name}**. I see you are working on **Step ${activeStep.step}: ${activeStep.title}**. Ask me any questions about wiring, coding in ${project.primaryLanguage}, database setup, or common errors!`,
        timestamp: new Date()
      }
    ]);
  }, [project.id, activeStep.step]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const newMsg: ChatMessage = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date()
    };
    
    const currentHistory = [...messages];
    
    setMessages(prev => [...prev, newMsg]);
    setInputMsg('');
    setIsTyping(true);

    api.activity.mentorChat(project.id, textToSend, currentHistory, project)
      .then((data) => {
        setIsTyping(false);
        setMessages(prev => [...prev, {
          sender: 'ai',
          text: data.reply,
          timestamp: new Date()
        }]);
      })
      .catch((err) => {
        setIsTyping(false);
        setMessages(prev => [...prev, {
          sender: 'ai',
          text: `⚠️ **AI Mentor Error:** ${err.message || 'Failed to get response from server.'}`,
          timestamp: new Date()
        }]);
      });
  };

  const suggestedQuestions = [
    { text: "How do I write code for this?", icon: Terminal },
    { text: "Show me the database schema", icon: MessageSquare },
    { text: project.hardware.length > 0 ? "How do I wire components?" : "Show APIs required", icon: Sparkles },
    { text: "What are common errors here?", icon: HelpCircle }
  ];

  return (
    <div className={`fixed bottom-4 right-4 z-40 w-full max-w-sm rounded-2xl border transition-all duration-300 shadow-2xl ${
      isOpen ? 'h-[520px]' : 'h-14'
    } ${
      theme === 'dark' ? 'glass-dark border-slate-800' : 'glass-light border-slate-200'
    } flex flex-col overflow-hidden`}>
      {/* Header bar */}
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between px-4 py-3.5 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border-b border-slate-900/10 cursor-pointer select-none"
      >
        <div className="flex items-center space-x-2">
          <MessageSquare className="w-5 h-5 text-indigo-400 animate-pulse" />
          <span className="font-bold text-sm font-heading tracking-wide">AI Project Mentor</span>
          <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-400">
            {progressPercent}%
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button className="text-slate-400 hover:text-slate-200">
            {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
          {onClose && (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="text-slate-405 hover:text-red-400"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {isOpen && (
        <>
          {/* Messages list */}
          <div className="flex-grow p-4 overflow-y-auto space-y-3.5 text-xs">
            {/* Scrollable instructions */}
            <div className={`p-3.5 rounded-xl border mb-2 text-xxs ${
              theme === 'dark' ? 'bg-slate-950/50 border-slate-900' : 'bg-slate-50 border-slate-150'
            }`}>
              <span className="font-bold block uppercase text-slate-500 tracking-wider mb-1.5">Next Recommended Task</span>
              <p className="font-semibold text-slate-350 leading-relaxed">
                Step {activeStep.step}: {activeStep.title} — {activeStep.description}
              </p>
            </div>

            {messages.map((msg, i) => (
              <div 
                key={i} 
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <span className="text-[9px] text-slate-500 mb-0.5 font-bold">
                  {msg.sender === 'user' ? 'You' : 'AI Mentor'}
                </span>
                <div 
                  className={`p-3 rounded-2xl max-w-[85%] leading-relaxed whitespace-pre-wrap ${
                    msg.sender === 'user'
                      ? 'bg-indigo-650 text-white rounded-tr-none'
                      : theme === 'dark'
                      ? 'bg-slate-900/80 border border-slate-850 text-slate-200 rounded-tl-none'
                      : 'bg-white border border-slate-150 text-slate-800 rounded-tl-none shadow-sm'
                  }`}
                >
                  {renderMarkdown(msg.text)}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center space-x-1.5 text-slate-500 pl-2">
                <span className="inline-block w-1.5 h-1.5 bg-slate-550 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="inline-block w-1.5 h-1.5 bg-slate-550 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="inline-block w-1.5 h-1.5 bg-slate-550 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Suggested options selection */}
          <div className="px-3 py-2 border-t border-slate-900/5 flex flex-wrap gap-1 bg-slate-900/10">
            {suggestedQuestions.map((q, i) => {
              const Icon = q.icon;
              return (
                <button
                  key={i}
                  onClick={() => handleSendMessage(q.text)}
                  className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold border transition-all ${
                    theme === 'dark'
                      ? 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700 hover:text-indigo-400'
                      : 'border-slate-200 bg-white text-slate-605 hover:border-slate-350 hover:text-indigo-600'
                  }`}
                >
                  <Icon className="w-3 h-3 text-indigo-400" />
                  <span>{q.text.split('?')[0]}</span>
                </button>
              );
            })}
          </div>

          {/* Form input */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputMsg);
            }} 
            className="p-3 border-t border-slate-900/10 flex items-center space-x-2"
          >
            <input
              type="text"
              value={inputMsg}
              onChange={(e) => setInputMsg(e.target.value)}
              placeholder="Ask anything..."
              className={`flex-grow px-3.5 py-2.5 rounded-xl border text-xs font-semibold outline-none transition-all ${
                theme === 'dark'
                  ? 'border-slate-850 bg-slate-950/40 text-slate-200 focus:border-indigo-550'
                  : 'border-slate-250 bg-white text-slate-800 focus:border-indigo-500'
              }`}
            />
            <button
              type="submit"
              disabled={!inputMsg.trim()}
              className="p-2.5 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white shadow-sm disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </>
      )}
    </div>
  );
}

function renderMarkdown(text: string) {
  const parts = text.split(/(```[\s\S]*?```)/g);
  
  return parts.map((part, i) => {
    if (part.startsWith('```')) {
      const match = part.match(/```(\w*)\n([\s\S]*?)```/);
      const lang = match ? match[1] : '';
      const code = match ? match[2] : part.replace(/```/g, '');
      
      return (
        <div key={i} className="my-3 rounded-xl border border-slate-850 bg-slate-950 overflow-hidden font-mono text-[10px] w-full text-left">
          <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-850 text-[9px] font-bold text-slate-400">
            <span>{lang || 'code'}</span>
            <button 
              type="button"
              onClick={() => navigator.clipboard.writeText(code)}
              className="hover:text-indigo-400 font-semibold cursor-pointer"
            >
              Copy
            </button>
          </div>
          <pre className="p-3 overflow-x-auto text-slate-350 leading-relaxed font-mono">
            <code>{code}</code>
          </pre>
        </div>
      );
    }

    const subParts = part.split(/(\*\*.*?\*\*|`.*?`)/g);
    
    return (
      <span key={i}>
        {subParts.map((sub, j) => {
          if (sub.startsWith('**') && sub.endsWith('**')) {
            return <strong key={j} className="font-extrabold text-indigo-400">{sub.slice(2, -2)}</strong>;
          }
          if (sub.startsWith('`') && sub.endsWith('`')) {
            return <code key={j} className="px-1.5 py-0.5 rounded bg-slate-950 border border-slate-850 text-indigo-400 font-mono text-[10px]">{sub.slice(1, -1)}</code>;
          }
          return sub;
        })}
      </span>
    );
  });
}
